﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using LitJson;

namespace testconsole
{
    class Program
    {
        /*
         入款:PayDemo.cs
         出款:DaifuDemo.cs
         回调:Callback.cs
         */
        /// <summary>
        /// 订单号时间字符串
        /// </summary>
        private static string dateStr = DateTime.Now.ToString("yyyyMMdd_");
        static void Main(string[] args)
        {
        }
    }
}
